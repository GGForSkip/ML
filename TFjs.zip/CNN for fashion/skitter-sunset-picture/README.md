TensorFlow.js Fashion MNIST classifier
=================

This experiment shows how you can use the power of Machine Learning directly in your browser to train and use a simple Neural Network with 3 layers (1 hidden) of the form (32 : 16 : 10) to classify fashion apparel from the Fashion MNIST dataset.