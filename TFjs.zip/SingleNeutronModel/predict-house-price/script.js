/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */

const status = document.getElementById('status');
if (status) {
  status.innerText = 'Loaded TensorFlow.js - version: ' + tf.version.tfjs;
}


import {TRAINING_DATA} from 'https://storage.googleapis.com/jmstore/TensorFlowJS/EdX/TrainingData/real-estate-data.js';



//Input features pairs (House size,Number of bedrooms)
const INPUTS=TRAINING_DATA.inputs;

//Current listed house prices in dollars given their feature above (target output values you want to predict)
const OUTPUTS=TRAINING_DATA.outputs;

//Shuffle the two arrays in the same way so inputs still match outputs indexes.
tf.util.shuffleCombo(INPUTS,OUTPUTS);


//Input featurss Array of Arrays needs 2D tensor to store
const INPUTS_TENSOR= tf.tensor2d(INPUTS);

//Output can stay  1 dimensional
const OUTPUT_TENSOR=tf.tensor1d(OUTPUTS);


//Function to take Tensor and noprmalize values
//with respect of each column of values contained in that Tensor
function normalize(tensor,min,max){
  const result=tf.tidy(function(){
    //Find min value inside tensor
    const MIN_VALUES= min || tf.min(tensor,0);
    
    //Find max value inside tensor
    const MAX_VALUES= max || tf.max(tensor,0);
    
    //Now subtract the MIN_VALUE from every value in the Tensor
    //and sotre result in a new Tensor
    const TENSOR_SUBTRACT_MIN_VALUE=tf.sub(tensor,MIN_VALUES);
    
    //Calculate the range size of possible values
    const RANGE_SIZE=tf.sub(MAX_VALUES,MIN_VALUES);
    
    //Calculate the adjusted values divided by the range size as a new Tensor
    const NORMALIZED_VALUES=tf.div(TENSOR_SUBTRACT_MIN_VALUE,RANGE_SIZE);
    
    return { NORMALIZED_VALUES,MIN_VALUES,MAX_VALUES};
    
    
  })
  
  return result;
}

//Normalize all input feature arrays and then
//dispose of the roginal non nomrlized Tensors.
const FEATURE_RESULTS=normalize(INPUTS_TENSOR);
console.log("Normalized values: ");
FEATURE_RESULTS.NORMALIZED_VALUES.print();

console.log('Min values:');
FEATURE_RESULTS.MIN_VALUES.print();

console.log('Max values:');
FEATURE_RESULTS.MAX_VALUES.print();

INPUTS_TENSOR.dispose();

//Now actually create and define module architetture
const model=tf.sequential();

//we will use one dense layer with 1 neuron (units) and an input of
//2 input feature values (representing house size and number of rooms)
model.add(tf.layers.dense({inputShape: [2], units: 1}));

model.summary();

train();


async function train(){
  const LEARNING_RATE=0.01; // choose learning rate that's suitable for the data we are using
  
  //Compile the model with the defined learning rate and specify a loss function to use
  model.compile({
    optimizer: tf.train.sgd(LEARNING_RATE),
    loss: 'meanSquaredError'
  });
  
  //Finally do the trainig itself
  let results=await model.fit(FEATURE_RESULTS.NORMALIZED_VALUES,OUTPUT_TENSOR,{
    validationSplit: 0.15, //take 15% of data to validate
    shuffle: true, //Ensure data is shuffled in case it was in order
    batchSize: 64, // as we have a lot of data, batch size id set to 64, numero di esempi provati priva di calcolare l average loss e l update di bias e weight
    epochs: 10 //Go over data 10 times!!
  });
  
  OUTPUT_TENSOR.dispose();
  FEATURE_RESULTS.NORMALIZED_VALUES.dispose();
  
  console.log("Average error loss: "+Math.sqrt(results.history.loss[results.history.loss.length-1]));
  console.log("Average validation error loss: "+Math.sqrt(results.history.val_loss[results.history.val_loss.length-1]));
  
 // evaluate();
  
}