
const status = document.getElementById('status');
if (status) {
  status.innerText = 'Loaded TensorFlow.js - version: ' + tf.version.tfjs;
}

//path of model.json file for read information about the model
const MODEL_PATH="https://storage.googleapis.com/jmstore/TensorFlowJs/Edx/SavedModels/sqftTopPropertyPrice/model.json"


let model=undefined;


async function loadModel(){
    model = await tf.loadModel(MODEL_PATH);
    model.summary();

    //Create a batch of 1
    const input= tf.tensor2d([[870]]);

    //Create a batch of 3
    const inputBatch= tf.tensor2d([[500],[1100],[970]]);

    //Actually make the predicition for each batch
    const result=model.predict(input);
    const resultBatch=model.predict(inputBatch);

    //Print results on console
    result.print(); //Or use .array() to get results back on array
    resultBatch.print(); //Or use .array() to get results back on array

    //clear memory from previous batch
    input.dispose();
    inputBatch.dispose();
    result.dispose();
    resultBatch.dispose();
    model.dispose();
}

loadModel();


//Save to local storage for offline access
await model.save('localstorage://demo/newModelName');


//check for saved models in local storage
console.log(JSON.stringify(await tf.io.listModels()));

//read from local storage with localstorage url
await tf.loadLayersModel("localstorage://demo/");