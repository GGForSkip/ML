Transfer Learning with MobileNet v3 in TensorFlow.js using saved graph model from TFHub.
=================

Learn how to make your very own Teachable Machine that can use the power of transfer learning to perform image recognition live in the browser powered by TensorFlow.js